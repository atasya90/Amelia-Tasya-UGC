# UGC Video & Motion Control Generator

Tools generator prompt video UGC untuk deploy di Vercel.

## Fitur
- Generator Prompt Video UGC
- Motion Control
- Storyboard 3x3 otomatis
- Pilihan Kling 3.0, Kling 2.6, Veo 3, Sora 2, Grok
- Export TXT dan JSON
- Copy prompt 1 klik
- UI premium dark mode

## Cara Deploy ke Vercel

1. Upload folder ini ke GitHub.
2. Buka https://vercel.com/new
3. Import repository.
4. Klik Deploy.

## Jalankan Lokal

```bash
npm install
npm run dev
```

Buka `http://localhost:3000`.
