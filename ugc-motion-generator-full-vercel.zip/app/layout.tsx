import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "UGC Video & Motion Control Generator",
  description: "Generator prompt video UGC, storyboard, dan motion control untuk Kling, Veo, Sora, Grok.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
