
"use client";

import { useMemo, useState } from "react";
import { Copy, Download, Sparkles, Wand2 } from "lucide-react";

type FormState = {
  productName: string;
  productDesc: string;
  audience: string;
  modelType: string;
  location: string;
  aiModel: string;
  duration: string;
  style: string;
  camera: string;
  voiceTone: string;
  cta: string;
  extraRules: string;
};

const initial: FormState = {
  productName: "Set outfit hijab Amelia Tasya Collection",
  productDesc: "Bahan adem, cutting rapi, nyaman untuk aktivitas harian dan cocok untuk konten TikTok Shop.",
  audience: "wanita 25–45 tahun",
  modelType: "wanita cantik 25 tahun Korea berhijab, wajah konsisten, senyum natural",
  location: "ruang tamu rumah mewah dengan signage Amelia Tasya Collection di dinding",
  aiModel: "Kling 3.0 Pro",
  duration: "15 detik",
  style: "UGC realistis TikTok affiliate",
  camera: "handheld iPhone natural, slow push-in, close-up produk, gerakan halus",
  voiceTone: "suara wanita muda Indonesia, natural, lembut, gaya ngobrol ke teman",
  cta: "cek keranjang kuning sekarang",
  extraRules: "tanpa watermark, produk tidak berubah warna/motif/bentuk, wajah tetap konsisten, pencahayaan natural"
};

function storyboardFrames(f: FormState) {
  return [
    `Frame 1: Hook pembuka, model menunjukkan ${f.productName} dekat kamera, ekspresi tertarik.`,
    `Frame 2: Medium shot, model berdiri di ${f.location}, memperlihatkan tampilan produk.`,
    `Frame 3: Close-up detail bahan, jahitan, motif, atau fitur utama produk.`,
    `Frame 4: Model mencoba atau memakai produk, gerakan natural dan percaya diri.`,
    `Frame 5: Kamera fokus pada detail penting, tangan menunjuk bagian produk.`,
    `Frame 6: Model berjalan pelan, outfit/produk terlihat jelas dari depan.`,
    `Frame 7: Side angle, model memperlihatkan produk dari sisi samping.`,
    `Frame 8: Ekspresi puas, model memberi gestur rekomendasi.`,
    `Frame 9: Closing, model tersenyum sambil memberi soft CTA: ${f.cta}.`
  ];
}

function buildPrompt(f: FormState) {
  const frames = storyboardFrames(f);
  return `PROMPT VIDEO UGC + MOTION CONTROL

AI MODEL:
${f.aiModel}

FORMAT:
Vertical 9:16, Ultra HD, realistic lighting, high quality, ${f.duration}, ${f.style}

PRODUK:
Nama produk: ${f.productName}
Deskripsi produk: ${f.productDesc}
Target audiens: ${f.audience}

KARAKTER / MODEL:
${f.modelType}
Ekspresi natural, senyum lembut, gaya afiliator TikTok, wajah konsisten dari awal sampai akhir.

LOKASI:
${f.location}
Suasana premium, bersih, modern, pencahayaan natural, realistis.

MOTION CONTROL:
- ${f.camera}
- Gerakan kamera stabil, tidak terlalu cepat, tidak patah-patah
- Model bergerak pelan: memegang produk, menunjukkan detail, mencoba produk, lalu tersenyum
- Produk tetap sama: warna, motif, ukuran, dan bentuk tidak berubah
- Fokus bergantian antara wajah model dan detail produk
- Depth of field lembut, cinematic realism

STORYBOARD 3x3:
${frames.map((x, i) => `${i + 1}. ${x}`).join("\n")}

VOICE OVER:
"${f.productName} ini cocok banget buat kamu yang pengen tampil rapi tapi tetap nyaman. Detailnya cantik, bahannya kelihatan premium, dan dipakai juga jatuhnya bagus banget. ${f.cta}."

TEXT OVERLAY OPSIONAL:
1. "Nyaman dipakai seharian"
2. "Detail premium"
3. "Wajib masuk wishlist"
4. "${f.cta}"

NEGATIVE PROMPT:
wajah berubah, bentuk tubuh berubah ekstrem, tangan rusak, jari berlebih, produk berubah warna, motif berubah, bahan jadi transparan, outfit robek, teks acak, watermark, logo palsu, blur, low quality, kamera terlalu cepat, scene tidak konsisten, background berubah drastis

ATURAN TAMBAHAN:
${f.extraRules}`;
}

function buildJson(f: FormState) {
  return JSON.stringify({
    ai_model: f.aiModel,
    aspect_ratio: "9:16",
    resolution: "Ultra HD",
    duration: f.duration,
    style: f.style,
    product: {
      name: f.productName,
      description: f.productDesc,
      audience: f.audience
    },
    character: f.modelType,
    location: f.location,
    motion_control: [
      f.camera,
      "stable natural handheld movement",
      "slow push-in",
      "close-up product details",
      "consistent face, product, color, motif, and outfit"
    ],
    storyboard_3x3: storyboardFrames(f),
    voice_over: `${f.productName} ini cocok banget buat kamu yang pengen tampil rapi tapi tetap nyaman. Detailnya cantik, bahannya kelihatan premium, dan dipakai juga jatuhnya bagus banget. ${f.cta}.`,
    negative_prompt: "face change, bad hands, extra fingers, product color change, motif change, watermark, blur, low quality, fast camera movement",
    extra_rules: f.extraRules
  }, null, 2);
}

export default function Home() {
  const [form, setForm] = useState<FormState>(initial);
  const [mode, setMode] = useState<"prompt" | "json" | "storyboard">("prompt");

  const prompt = useMemo(() => buildPrompt(form), [form]);
  const json = useMemo(() => buildJson(form), [form]);
  const storyboard = useMemo(() => storyboardFrames(form).map((x, i) => `Frame ${i + 1}\n${x}`).join("\n\n"), [form]);
  const output = mode === "prompt" ? prompt : mode === "json" ? json : storyboard;

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function copy() {
    navigator.clipboard.writeText(output);
  }

  function download(ext: "txt" | "json") {
    const blob = new Blob([ext === "json" ? json : output], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = ext === "json" ? "ugc-motion-prompt.json" : "ugc-motion-prompt.txt";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,#3b0764,#050510_45%,#020617)] px-4 py-8">
      <div className="mx-auto max-w-7xl">
        <section className="mb-8 rounded-3xl border border-white/10 bg-white/5 p-6 shadow-glow backdrop-blur">
          <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="mb-2 inline-flex items-center gap-2 rounded-full bg-pink-500/15 px-3 py-1 text-sm text-pink-200">
                <Sparkles size={16} /> AI Tools for TikTok Affiliate
              </p>
              <h1 className="text-3xl font-black tracking-tight md:text-5xl">
                UGC Video & Motion Control Generator
              </h1>
              <p className="mt-3 max-w-3xl text-neutral-300">
                Buat prompt video UGC, storyboard 3x3, motion control, voice over, dan negative prompt untuk Kling 3.0, Kling 2.6, Veo 3, Sora 2, dan Grok.
              </p>
            </div>
            <button
              onClick={() => setForm(initial)}
              className="rounded-2xl bg-white px-5 py-3 font-bold text-neutral-950 transition hover:bg-pink-100"
            >
              Reset Template
            </button>
          </div>
        </section>

        <div className="grid gap-6 lg:grid-cols-2">
          <section className="rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur">
            <div className="mb-5 flex items-center gap-2 text-xl font-bold">
              <Wand2 className="text-pink-300" /> Input Generator
            </div>

            <div className="grid gap-4">
              <Field label="Nama Produk" value={form.productName} onChange={(v) => update("productName", v)} />
              <TextArea label="Deskripsi Produk" value={form.productDesc} onChange={(v) => update("productDesc", v)} />
              <Field label="Target Audiens" value={form.audience} onChange={(v) => update("audience", v)} />
              <Field label="Karakter / Model" value={form.modelType} onChange={(v) => update("modelType", v)} />
              <Field label="Lokasi" value={form.location} onChange={(v) => update("location", v)} />

              <div className="grid gap-4 md:grid-cols-2">
                <Select label="Model AI" value={form.aiModel} onChange={(v) => update("aiModel", v)} options={["Kling 3.0 Pro", "Kling 3.0 Standard", "Kling 2.6 Pro", "Kling 2.6 Standard", "Veo 3", "Sora 2", "Grok Video"]} />
                <Select label="Durasi" value={form.duration} onChange={(v) => update("duration", v)} options={["6 detik", "8 detik", "10 detik", "15 detik", "20 detik", "30 detik", "45 detik"]} />
              </div>

              <Select label="Style Video" value={form.style} onChange={(v) => update("style", v)} options={["UGC realistis TikTok affiliate", "Mirror selfie fashion showcase", "Cinematic product review", "Unboxing natural", "Luxury home review", "Vlog jalan di taman", "POV affiliator"]} />
              <Field label="Motion Camera" value={form.camera} onChange={(v) => update("camera", v)} />
              <Field label="Tone Voice Over" value={form.voiceTone} onChange={(v) => update("voiceTone", v)} />
              <Field label="CTA" value={form.cta} onChange={(v) => update("cta", v)} />
              <TextArea label="Aturan Tambahan" value={form.extraRules} onChange={(v) => update("extraRules", v)} />
            </div>
          </section>

          <section className="rounded-3xl border border-white/10 bg-neutral-950/70 p-5 backdrop-blur">
            <div className="mb-4 flex flex-wrap gap-2">
              <Tab active={mode === "prompt"} onClick={() => setMode("prompt")}>Prompt</Tab>
              <Tab active={mode === "storyboard"} onClick={() => setMode("storyboard")}>Storyboard 3x3</Tab>
              <Tab active={mode === "json"} onClick={() => setMode("json")}>JSON</Tab>
            </div>

            <textarea
              className="h-[640px] w-full rounded-2xl border border-white/10 bg-black/40 p-4 text-sm leading-6 text-neutral-100"
              value={output}
              readOnly
            />

            <div className="mt-4 grid gap-3 md:grid-cols-3">
              <button onClick={copy} className="inline-flex items-center justify-center gap-2 rounded-2xl bg-pink-600 px-4 py-3 font-bold hover:bg-pink-500">
                <Copy size={18} /> Copy
              </button>
              <button onClick={() => download("txt")} className="inline-flex items-center justify-center gap-2 rounded-2xl bg-white/10 px-4 py-3 font-bold hover:bg-white/15">
                <Download size={18} /> Export TXT
              </button>
              <button onClick={() => download("json")} className="inline-flex items-center justify-center gap-2 rounded-2xl bg-white/10 px-4 py-3 font-bold hover:bg-white/15">
                <Download size={18} /> Export JSON
              </button>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="grid gap-2">
      <span className="text-sm font-semibold text-neutral-200">{label}</span>
      <input
        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white placeholder:text-neutral-500 focus:border-pink-400"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

function TextArea({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="grid gap-2">
      <span className="text-sm font-semibold text-neutral-200">{label}</span>
      <textarea
        className="min-h-24 rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white placeholder:text-neutral-500 focus:border-pink-400"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

function Select({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <label className="grid gap-2">
      <span className="text-sm font-semibold text-neutral-200">{label}</span>
      <select
        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white focus:border-pink-400"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((x) => <option key={x}>{x}</option>)}
      </select>
    </label>
  );
}

function Tab({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-2xl px-4 py-2 font-bold transition ${active ? "bg-pink-600 text-white" : "bg-white/10 text-neutral-200 hover:bg-white/15"}`}
    >
      {children}
    </button>
  );
}
